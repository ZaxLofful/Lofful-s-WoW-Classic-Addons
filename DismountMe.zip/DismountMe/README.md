# DismountMe
A WoW Classic Addon that automatically unmounts the player when using an action. It is quite similar to ezDismount, as it unmounts the player whenever an action is used which cannot be done mounted or shapeshifted, however it's written minimal and designed to work on every localized gameclient.

## Installation
1. Download **[Latest Version](https://github.com/fadichmn/DismountMe/archive/1.0.zip)**
2. Unpack the Zip file
3. Copy "DismountMe" into \Interface\AddOns\
4. Restart WoW
5. ENJOY
